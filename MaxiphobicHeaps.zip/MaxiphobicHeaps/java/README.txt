Instructions

1)  Start Eclipse.
2)  Go to File menu -> Import -> General -> Existing Projects into Workspace + Next.
3)  Select archive file + Browse.
4)  Select MXH.zip in this folder + Finish.
5)  Project should be now in Eclipse's workspace.