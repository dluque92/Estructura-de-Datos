/**
 * @author <<write here your name>> 
 * 
 * Maxiphobic Heaps
 * Data Structures, Grado en Informática. UMA.
 *
 */
 
package dataStructures.heap;


/**
 * Heap implemented using maxiphobic heap-ordered binary trees.
 * @param <T> Type of elements in heap.
 */
public class MaxiphobicHeap<T extends Comparable<? super T>> implements	Heap<T> {

	protected static class Tree<E> {
		E elem;
		int weight;
		Tree<E> left;
		Tree<E> right;
	}

	private static int weight(Tree<?> heap) {
		return heap == null ? 0 : heap.weight;
	}

	private static <T extends Comparable<? super T>> Tree<T> merge(Tree<T> h1,	Tree<T> h2) {
		// TODO
	}

	protected Tree<T> root;

	/**
	 * Constructor: creates an empty Maxiphobic Heap. 
	 * <p>Time complexity: ???
	 */
	public MaxiphobicHeap() {
		// TODO
	}

	/** 
	 * <p>Time complexity: ???
	 */
	public boolean isEmpty() {
		// TODO
	}

	/** 
	 * <p>Time complexity: ???
	 * @throws <code>EmptyHeapException</code> if heap stores no element.
	 */
	public T minElem() {
		// TODO
	}

	/** 
	 * <p>Time complexity: ???
	 * @throws <code>EmptyHeapException</code> if heap stores no element.
	 */
	public void delMin() {
		// TODO
	}

	/** 
	 * <p>Time complexity: ???
	 */
	public void insert(T value) {
		// TODO
	}

	private static String toStringRec(Tree<?> tree) {
		return tree == null ? "null" : "Node<" + toStringRec(tree.left) + ","
				+ tree.elem + "," + toStringRec(tree.right) + ">";
	}
	
	/** 
	 * Returns representation of heap as a String.
	 */
	public String toString() {
		String className = getClass().getSimpleName();

		return className+"("+toStringRec(this.root)+")";
	}	
	
}